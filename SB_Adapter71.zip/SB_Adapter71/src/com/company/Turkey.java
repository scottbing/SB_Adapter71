package com.company;

public interface Turkey {
    void gobble();
    void fly();
}
