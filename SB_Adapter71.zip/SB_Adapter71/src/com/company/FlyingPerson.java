package com.company;

public interface FlyingPerson {
    public void yikes();
    public void fly();
}
